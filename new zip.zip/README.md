# Cypress Automation Framework - Prowl2 Wayvia

This project implements a comprehensive Cypress automation framework for testing the Prowl2 Wayvia application using Page Object Model (POM) structure, test data management, and Mochawesome reporting.

## 🚀 Features

- **Page Object Model (POM)**: Clean separation of page elements and test logic
- **Test Data Management**: JSON fixtures for easy test data management
- **Mochawesome Reporting**: Professional HTML reports with screenshots
- **Custom Commands**: Reusable Cypress commands for common operations
- **Organized Test Structure**: Tests organized by feature/functionality
- **Screenshot on Failure**: Automatic screenshot capture on test failures
- **Responsive Testing**: Support for mobile, tablet, and desktop viewports
- **Session Management**: Efficient login session handling

## 📁 Project Structure

```
cypress/
├── e2e/
│   ├── login/
│   │   └── login.cy.js           # Login functionality tests
│   └── dashboard/
│       └── dashboard.cy.js       # Dashboard functionality tests
├── pages/
│   ├── LoginPage.js               # Login page object model
│   └── DashboardPage.js           # Dashboard page object model
├── fixtures/
│   └── testData.json              # Test data for all tests
├── support/
│   ├── commands.js                # Custom Cypress commands
│   └── e2e.js                     # Global configuration and setup
└── reports/                       # Generated test reports
    └── mochawesome-report/
```

## 🛠️ Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd prowl2wayvia
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

## 🧪 Running Tests

### Interactive Mode (Cypress UI)
```bash
npm run cy:open
```

### Headless Mode
```bash
# Run all tests
npm test

# Run with browser visible
npm run test:headed

# Run specific browser
npm run test:chrome
npm run test:firefox

# Run specific test suite
npm run test:login
npm run test:dashboard
```

### Individual Test Execution
```bash
# Run specific test file
npx cypress run --spec "cypress/e2e/login/login.cy.js"

# Run tests with specific browser
npx cypress run --browser chrome --spec "cypress/e2e/login/login.cy.js"
```

## 📊 Test Reporting

### Generate Reports
```bash
# Generate combined Mochawesome report
npm run report:full

# Or step by step
npm run report:merge
npm run report:generate
```

### View Reports
After running tests, open `cypress/reports/report.html` in your browser to view the detailed test report.

### Clean Reports
```bash
npm run clean:reports
```

## 🔧 Configuration

### Cypress Configuration (`cypress.config.js`)
- **Base URL**: https://prowl2.wayvia.com
- **Viewport**: 1280x720
- **Timeouts**: 10 seconds for commands, requests, and responses
- **Videos**: Enabled for test runs
- **Screenshots**: Enabled on failure

### Test Data (`cypress/fixtures/testData.json`)
- Valid and invalid user credentials
- Test users with different roles
- Error messages and URL configurations
- Easily maintainable and extendable

## 📋 Test Cases

### Login Tests (`login.cy.js`)
- **TC_01**: Verify login with valid credentials
- **TC_02**: Verify error message for invalid credentials
- **TC_03**: Verify UI elements (username, password, login button)
- **TC_04**: Verify successful redirection after login
- **Additional**: Forgot password functionality, responsive design tests

### Dashboard Tests (`dashboard.cy.js`)
- Dashboard display and navigation tests
- User profile verification
- Content loading and functionality tests
- Responsive design tests
- Performance tests

## 🎯 Page Object Model

### LoginPage.js
- **Locators**: Email input, password input, login button, forgot password link
- **Methods**: 
  - `enterUsername(username)`
  - `enterPassword(password)`
  - `clickLogin()`
  - `verifyLoginError()`
  - `verifyLoginPageElements()`

### DashboardPage.js
- **Locators**: Dashboard header, profile icon, navigation elements
- **Methods**:
  - `verifyDashboardVisible()`
  - `verifyUserLoggedIn()`
  - `verifyDashboardContent()`

## 🛡️ Custom Commands

- `cy.login(username, password)` - Login with credentials
- `cy.loginWithFixture(userType)` - Login using fixture data
- `cy.logout()` - Logout user
- `cy.waitForPageLoad()` - Wait for page to fully load
- `cy.takeScreenshot(name)` - Take screenshot with timestamp
- `cy.clearSession()` - Clear all session data

## 🐛 Error Handling

- Automatic screenshot capture on test failures
- Uncaught exception handling to prevent test interruption
- Comprehensive error messages and assertions
- Retry mechanisms for flaky elements

## 📱 Responsive Testing

Tests include viewport testing for:
- **Mobile**: iPhone 6 (375x667)
- **Tablet**: iPad 2 (768x1024)
- **Desktop**: 1920x1080

## 🔄 Continuous Integration

The framework is designed to work with CI/CD pipelines:
- Headless execution support
- JUnit XML reports for CI integration
- Video recordings for failed tests
- Configurable browser selection

## 📝 Best Practices

1. **Page Object Model**: Keep page elements and actions separate from tests
2. **Test Data**: Use fixtures for test data management
3. **Custom Commands**: Create reusable commands for common operations
4. **Assertions**: Use meaningful assertions with clear error messages
5. **Wait Strategies**: Use proper wait strategies instead of hard waits
6. **Screenshots**: Take screenshots for debugging failed tests

## 🚦 Getting Started

1. **Update Test Data**: Modify `cypress/fixtures/testData.json` with valid credentials
2. **Run Initial Test**: `npm run cy:open` to open Cypress and run a test
3. **View Results**: Check the generated reports in `cypress/reports/`
4. **Customize**: Add new page objects and tests as needed

## 📞 Support

For issues or questions about the framework:
1. Check the Cypress documentation: https://docs.cypress.io
2. Review the test reports for detailed error information
3. Check the console output for debugging information

## 🔄 Version History

- **v1.0.0**: Initial framework setup with POM, test data management, and Mochawesome reporting# prowl2-qa-automation
