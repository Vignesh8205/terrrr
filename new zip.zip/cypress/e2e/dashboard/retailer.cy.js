import RetailerPage from '../../pages/RetailerPage'
/// <reference types="cypress" />
describe('Retailer Functionality', () => {
    let testData
    const retailerPage = new RetailerPage()

    before(() => {
        cy.fixture('testData').then((data) => {
            testData = data
        })
    })

    beforeEach(() => {
        // Login before each test using custom command
        cy.loginWithFixture('validUser')
        cy.visit('/')
        retailerPage.navigateToRetailerTab()
    })

    describe('Verify Retailer Page Functionality', () => {
        it('should verify all retailer components and user actions after successful login', () => {
            retailerPage.navigateToRetailerTab()
            retailerPage.verifyRetailerVisible()
            retailerPage.verifyRetailerContent(testData.retailerPage.pageContent)
            retailerPage.validateAllRetailerAndSellerData()
            retailerPage.verifyDownloadedFileCanBeOpened()
            retailerPage.selectRowPerPage('50')
            retailerPage.enteredFilterDetails(testData.retailerPage.FilterDetails)
            retailerPage.clickOnPagiNationValidateMoveOnNextPage()
            // retailerPage.clickOnTheSellerLinkAndValidateNavigateToAnotherTab()

        })

        it('Should verify search functionality for a specific retailer', () => {
            retailerPage.verifySearchWorks("heb.com")
        })




    })

    describe("Verify Retailer Details Page Functionality", () => {
        it("verify retailer row opens the retailer details page", () => {
            retailerPage.clicktableCellData()
            retailerPage.checkRetailerDetails()
            retailerPage.checkCompilanceSummary()
        })

        it.only("should verify all tabs are present in the Retailer Details page and all sub-titles are displayed in the Overview tab", () => {
            retailerPage.clicktableCellData()
            retailerPage.verifyTabsIsPresent(testData.retailerPage.retailerDetailsPage.tabs)
            retailerPage.verifyTabIsEnabled(testData.retailerPage.retailerDetailsPage.tabs[0])
            retailerPage.verifyAllSubTitlesArePresent(testData.retailerPage.retailerDetailsPage.subTitles)
        })

        it('should verify all sub-titles are displayed in the Compliance History tab', () => {
            retailerPage.clicktableCellData()
            retailerPage.navigateToTab(testData.retailerPage.retailerDetailsPage.tabs[1])
            retailerPage.verifyTabIsEnabled(testData.retailerPage.retailerDetailsPage.tabs[1])
            retailerPage.verifyAllSubTitlesArePresent(["Violation History"])
            retailerPage.verifyTableHeaders(testData.retailerPage.retailerDetailsPage.ComplianceHistoryHeaders)
            retailerPage.selectItemPerPage('50')
            retailerPage.clickOnPagiNationValidateMoveOnNextPageInComplianceHistory()

        })


        it('should verify all sub-titles are displayed in the Compliance History tab', () => {
            retailerPage.clicktableCellData()
            retailerPage.navigateToTab(testData.retailerPage.retailerDetailsPage.tabs[2])
            retailerPage.verifyTabIsEnabled(testData.retailerPage.retailerDetailsPage.tabs[2])
            retailerPage.verifyAllSubTitlesArePresent(["Match Statistics"])
            retailerPage.verifyTableHeaders(testData.retailerPage.retailerDetailsPage.ProductsHeaders)
            retailerPage.selectItemPerPageForProducts('50')
            retailerPage.clickOnPagiNationValidateMoveOnNextPageInComplianceHistory()

            retailerPage.selectActiveStatus("Inactive Only")
            retailerPage.selectViolationStatus("Violations Only")
            retailerPage.selectStockStatus("In Stock Only")

        })

    })











})




