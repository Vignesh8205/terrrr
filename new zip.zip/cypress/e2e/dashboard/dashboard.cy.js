import DashboardPage from '../../pages/DashboardPage'

describe('Dashboard Functionality', () => {
  let testData
  const dashboardPage = new DashboardPage()

  before(() => {
    cy.fixture('testData').then((data) => {
      testData = data
    })
  })

  beforeEach(() => {
    // Login before each test using custom command
    cy.loginWithFixture('validUser')
    cy.visit('/')
  })

  describe('Dashboard Display and User Interaction Tests', () => {
    it('should verify all dashboard components and user actions after successful login', () => {
      dashboardPage.verifyDashboardVisible()
      dashboardPage.verifyUserLoggedIn()
      dashboardPage.verifyDashboardContent(testData.dasboardPage.pageContent)
      dashboardPage.changeMonthMAPViolationTrends(testData.dasboardPage.historicalviolationMonth)
      dashboardPage.clickOnRecentMAPViolationsButton(testData.dasboardPage.recentMAPViolations.button1)
      dashboardPage.clickOnCheckbox()
      dashboardPage.clickOnRecentMAPViolationsButton(testData.dasboardPage.recentMAPViolations.button2)
      dashboardPage.chooseTheOption(testData.dasboardPage.DensityOptions.option1)
      dashboardPage.validateDensity(testData.dasboardPage.expectedDensityStyles.Comfortable)
      dashboardPage.openFilterPanel()
      dashboardPage.enterFilterDetails(testData.dasboardPage.FilterDetails)
      dashboardPage.reloadPage()
      dashboardPage.performSearch('petco.com')
      dashboardPage.selectRowPerPage('20')
      dashboardPage.clickDownloadButton()
      dashboardPage.clickOnPagiNationValidateMoveOnNextPage()
    })




  })
})


