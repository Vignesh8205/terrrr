import LoginPage from '../../pages/LoginPage'
import DashboardPage from '../../pages/DashboardPage'

describe('Login Functionality', () => {
  let testData
  const loginPage = new LoginPage()
  const dashboardPage = new DashboardPage()

  before(() => {
    cy.fixture('testData').then((data) => {
      testData = data
    })
  })

  beforeEach(() => {
    cy.clearSession()
    loginPage.visit()
  })

  describe('TC_01: Verify login with valid credentials', () => {
    it.only('should login successfully with valid credentials from fixture', () => {
      // Arrange
      const validUser = testData.validUser

      // Act
      loginPage
        .enterUsername(validUser.username)
        .enterPassword(validUser.password)
        .clickLogin()

      // Assert
      cy.url().should('not.include', '/login')
      dashboardPage.verifyDashboardVisible()
      dashboardPage.verifyUserLoggedIn()
    })

    it('should login successfully with test user credentials', () => {
      // Arrange
      const testUser = testData.testUsers[0]

      // Act
      loginPage.login(testUser.username, testUser.password)

      // Assert
      cy.url().should('not.include', '/login')
      dashboardPage.verifyDashboardVisible()
    })
  })

  describe('TC_02: Verify error message for invalid credentials', () => {
    it('should show error message for invalid username and password', () => {
      // Arrange
      const invalidUser = testData.invalidUser

      // Act
      loginPage.login(invalidUser.username, invalidUser.password)

      // Assert
      cy.url().should('include', '/login')
      // Note: Error message verification depends on actual application behavior
      // This is a placeholder that may need adjustment based on actual error handling
      cy.get('body').should('contain.text', 'Invalid').or('contain.text', 'Error')
    })

    it('should show error message for empty credentials', () => {
      // Act
      loginPage.clickLogin()

      // Assert
      cy.url().should('include', '/login')
      // Verify form validation for required fields
      loginPage.emailInput.should('have.attr', 'required')
      loginPage.passwordInput.should('have.attr', 'required')
    })

    it('should show error message for invalid email format', () => {
      // Act
      loginPage
        .enterUsername('invalid-email')
        .enterPassword('somepassword')
        .clickLogin()

      // Assert
      cy.url().should('include', '/login')
      // Email validation should prevent form submission or show error
    })
  })

  describe('TC_03: Verify UI elements', () => {
    it('should display all login page elements correctly', () => {
      // Assert
      loginPage.verifyLoginPageElements()
      
      // Verify input field properties
      loginPage.emailInput
        .should('have.attr', 'type', 'text')
        .and('have.attr', 'autocomplete', 'email')
        .and('have.attr', 'required')

      loginPage.passwordInput
        .should('have.attr', 'type', 'password')
        .and('have.attr', 'autocomplete', 'current-password')
        .and('have.attr', 'required')

      // Verify button properties
      loginPage.loginButton
        .should('have.attr', 'type', 'submit')
        .and('contain.text', 'Login')

      // Verify forgot password link
      loginPage.forgotPasswordLink
        .should('have.attr', 'href', '/forgot-password')
        .and('contain.text', 'Forgot Password?')
    })

    it('should have proper form structure and accessibility', () => {
      // Verify form structure
      loginPage.loginForm.should('exist')
      
      // Verify labels are properly associated with inputs
      cy.get('#email-label').should('exist')
      cy.get('#password-label').should('exist')
      
      // Verify input fields have proper IDs
      loginPage.emailInput.should('have.attr', 'id', 'email')
      loginPage.passwordInput.should('have.attr', 'id', 'password')
    })
  })

  describe('TC_04: Verify successful redirection after login', () => {
    it('should redirect to dashboard after successful login', () => {
      // Arrange
      const validUser = testData.validUser

      // Act
      loginPage.login(validUser.username, validUser.password)

      // Assert
      cy.url().should('not.include', '/login')
      dashboardPage.verifyDashboardVisible()
      dashboardPage.verifyDashboardContent()
    })

    it('should maintain session after successful login', () => {
      // Arrange
      const validUser = testData.validUser

      // Act
      loginPage.login(validUser.username, validUser.password)
      
      // Verify dashboard is accessible
      dashboardPage.verifyDashboardVisible()
      
      // Refresh the page
      cy.reload()
      
      // Assert
      cy.url().should('not.include', '/login')
      dashboardPage.verifyDashboardVisible()
    })
  })

  describe('Forgot Password Functionality', () => {
    it('should navigate to forgot password page', () => {
      // Act
      loginPage.clickForgotPassword()

      // Assert
      cy.url().should('include', '/forgot-password')
    })
  })

  describe('Responsive Design Tests', () => {
    it('should display properly on mobile viewport', () => {
      // Arrange
      cy.viewport('iphone-6')

      // Assert
      loginPage.verifyLoginPageElements()
      loginPage.loginForm.should('be.visible')
    })

    it('should display properly on tablet viewport', () => {
      // Arrange
      cy.viewport('ipad-2')

      // Assert
      loginPage.verifyLoginPageElements()
      loginPage.loginForm.should('be.visible')
    })
  })
})