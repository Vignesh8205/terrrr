// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************

import LoginPage from '../pages/LoginPage'
import DashboardPage from '../pages/DashboardPage'

// Custom command to login with credentials
Cypress.Commands.add('login', (username, password) => {
  const loginPage = new LoginPage()
  
  cy.session([username, password], () => {
    cy.visit('/login')
    loginPage.login(username, password)
    
    // Wait for successful login (redirect away from login page)
    cy.url().should('not.include', '/login')
  })
})

// Custom command to login using fixture data
Cypress.Commands.add('loginWithFixture', (userType = 'validUser') => {
  cy.fixture('testData').then((data) => {
    const user = data[userType]
    cy.login(user.username, user.password)
  })
})

// Custom command to logout
Cypress.Commands.add('logout', () => {
  const dashboardPage = new DashboardPage()
  dashboardPage.logout()
  cy.url().should('include', '/login')
})

// Custom command to verify element is visible and contains text
Cypress.Commands.add('shouldBeVisibleAndContain', { prevSubject: 'element' }, (subject, text) => {
  cy.wrap(subject).should('be.visible').and('contain.text', text)
})

// Custom command to wait for page to load
Cypress.Commands.add('waitForPageLoad', () => {
  cy.get('body').should('not.contain', 'Loading...')
  cy.get('body').should('be.visible')
})

// Custom command to take screenshot with timestamp
Cypress.Commands.add('takeScreenshot', (name) => {
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-')
  cy.screenshot(`${name}-${timestamp}`)
})

// Custom command to clear session and cookies
Cypress.Commands.add('clearSession', () => {
  cy.clearCookies()
  cy.clearLocalStorage()
  cy.window().then((win) => {
    win.sessionStorage.clear()
  })
})

// Custom command to verify URL contains expected path
Cypress.Commands.add('verifyUrl', (expectedPath) => {
  cy.url().should('include', expectedPath)
})

// Custom command to handle form validation
Cypress.Commands.add('verifyFormValidation', (selector, expectedMessage) => {
  cy.get(selector)
    .should('have.attr', 'aria-invalid', 'true')
    .siblings('.error-message, .MuiFormHelperText-root')
    .should('contain.text', expectedMessage)
})

// Override the visit command to add error handling
Cypress.Commands.overwrite('visit', (originalFn, url, options) => {
  return originalFn(url, {
    ...options,
    failOnStatusCode: false,
    timeout: 30000
  })
})