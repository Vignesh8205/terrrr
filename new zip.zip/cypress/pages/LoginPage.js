class LoginPage {
  // Locators based on the provided HTML structure
  get emailInput() {
    return cy.get('#email')
  }

  get passwordInput() {
    return cy.get('#password')
  }

  get loginButton() {
    return cy.get('button[type="submit"]').contains('Login')
  }

  get forgotPasswordLink() {
    return cy.get('a[href="/forgot-password"]').contains('Forgot Password?')
  }

  get loginForm() {
    return cy.get('form')
  }

  get wayviaLogo() {
    return cy.get('img[alt="Wayvia Logo"]')
  }

  get loginHeader() {
    return cy.get('h1').contains('Login')
  }

  get errorMessage() {
    return cy.get('[data-testid="error-message"]')
  }

  // Methods
  visit() {
    cy.visit('/login')
  }

  enterUsername(username) {
    this.emailInput.clear().type(username)
    return this
  }

  enterPassword(password) {
    this.passwordInput.clear().type(password)
    return this
  }

  clickLogin() {
    this.loginButton.click()
    return this
  }

  clickForgotPassword() {
    this.forgotPasswordLink.click()
    return this
  }

  verifyLoginPageElements() {
    this.wayviaLogo.should('be.visible')
    this.loginHeader.should('be.visible')
    this.emailInput.should('be.visible')
    this.passwordInput.should('be.visible')
    this.loginButton.should('be.visible')
    this.forgotPasswordLink.should('be.visible')
    return this
  }

  verifyLoginError(errorText) {
    this.errorMessage.should('be.visible').and('contain.text', errorText)
    return this
  }

  login(username, password) {
    this.enterUsername(username)
    this.enterPassword(password)
    this.clickLogin()
    return this
  }
}

export default LoginPage