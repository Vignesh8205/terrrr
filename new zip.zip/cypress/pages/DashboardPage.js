// import { expect } from "chai"

class DashboardPage {
  // Locators for dashboard elements
  get dashboardHeader() {
    return cy.get('[data-testid="dashboard-header"]')
  }

  get profileIcon() {
    return cy.get('[data-testid="profile-icon"]')
  }

  get navigationMenu() {
    return cy.get('[data-testid="navigation-menu"]')
  }

  get welcomeMessage() {
    return cy.get('[data-testid="welcome-message"]')
  }

  get logoutButton() {
    return cy.get('[data-testid="logout-button"]')
  }

  get mainContent() {
    return cy.get('[data-testid="main-content"]')
  }

  // Alternative selectors in case data-testid is not available
  get dashboardTitle() {
    return cy.get('h1, h2, h3').contains(/dashboard/i)
  }

  get userProfile() {
    return cy.get('[aria-label*="profile"], [title*="profile"]')
  }

  get MonthMAPViolationTrendsButton() {
    return cy.get('[class*="MuiCardHeader-content"]>span>div>span:nth-child(1)')
  }

  //role="menuitem"
  get monthhistoricalviolationdetectiondata() {
    return cy.get('[role="menuitem"]')
  }

  get currentMonthMAPViolationTrends() {
    return cy.get('[class*="MuiCardHeader-subheader"]')
  }

  get recentMAPViolations() {
    return cy.get('[aria-haspopup="menu"]')


  }

  get recentMAPViolationsTableHeader() {
    return cy.get('[class*="MuiDataGrid-columnHeaderTitle"]')
  }

  get checkboxelement() {
    return cy.get('[name="seller"]')
  }

  get tableRows() {
    return cy.get('[class="MuiDataGrid-row"]')
  }

  get downloadButton() {
    return cy.get('[data-testid="DownloadIcon"]')
  }

  get searchDashboardTable() {
    return cy.get('[data-testid="SearchIcon"]')
  }

  get searchInput() {
    return cy.get('input[placeholder*="Search by product"], input[id*=":r3t:"]')
  }

  get tableValue() {
    return cy.get('[role="gridcell"]')
  }

  get searchButton() {
    return cy.get('button').contains('Search')
  }


  get filterIcon() {
    return cy.get('[data-testid="FilterListIcon"]')
  }

  get skuInput() {
    return cy.get('input[placeholder="Enter SKU"]')
  }

  get urlInput() {
    return cy.get('input[placeholder="Enter URL"]')
  }

  get minViolationInput() {
    return cy.get('input[placeholder="0.00"]')
  }

  get maxViolationInput() {
    return cy.get('input[placeholder="100.00"]')
  }

  get fromDateInput() {
    return cy.get('input[type="date"]').eq(0)
  }

  get toDateInput() {
    return cy.get('input[type="date"]').eq(1)
  }

  get applyFilterButton() {
    return cy.contains('button', 'Apply Filters')
  }

  get rowperPageDropdown() {
    return cy.get('div.MuiTablePagination-select')
  }

  get rowperPageOption() {
    return cy.get('li[data-value="20"')
  }

  get nextPageButton() {
    return cy.get('[aria-label="Go to next page"]')
  }
get paginationCountElement() {
    return cy.get('[class*="MuiTablePagination-displayedRows"]')
  }



  // Methods
  verifyDashboardVisible() {
    // Check if we're redirected away from login page
    cy.url().should('not.include', '/login')

    // Try multiple approaches to verify dashboard is loaded
    cy.get('body').then(($body) => {
      if ($body.find('[data-testid="dashboard-header"]').length > 0) {
        this.dashboardHeader.should('be.visible')
      } else if ($body.find('h1, h2, h3').text().toLowerCase().includes('dashboard')) {
        this.dashboardTitle.should('be.visible')
      } else {
        // Fallback - check for common dashboard elements
        cy.get('main, [role="main"], .dashboard, #dashboard').should('exist')
      }
    })

    return this
  }

  verifyUserLoggedIn() {
    // Verify user is authenticated by checking for profile elements or user info
    cy.get('body').then(($body) => {
      if ($body.find('[data-testid="profile-icon"]').length > 0) {
        this.profileIcon.should('be.visible')
      } else if ($body.find('[aria-label*="profile"], [title*="profile"]').length > 0) {
        this.userProfile.should('be.visible')
      } else {
        // Fallback - check URL doesn't contain login
        cy.url().should('not.include', '/login')
      }
    })

    return this
  }

  clickProfile() {
    cy.get('body').then(($body) => {
      if ($body.find('[data-testid="profile-icon"]').length > 0) {
        this.profileIcon.click()
      } else {
        this.userProfile.first().click()
      }
    })
    return this
  }

  logout() {
    cy.get('body').then(($body) => {
      if ($body.find('[data-testid="logout-button"]').length > 0) {
        this.logoutButton.click()
      } else {
        // Look for common logout patterns
        cy.get('button, a').contains(/logout|sign out/i).click()
      }
    })
    return this
  }

  verifyDashboardContent(pageContent) {
    // Verify the main dashboard content is loaded
    cy.get('body').should('not.contain', 'Loading...')

    pageContent.forEach((content) => {
      cy.get('h3').should('contain.text', content)
    }
    )    // cy.get('h3').should('be.visible')
    return this
  }


  changeMonthMAPViolationTrends(option) {
    this.MonthMAPViolationTrendsButton.click()
    this.monthhistoricalviolationdetectiondata.contains(option).click()
    this.currentMonthMAPViolationTrends.should('contain.text', option)
    return this
  }

  clickOnRecentMAPViolationsButton(name) {
    this.recentMAPViolations.contains(name).click()
    return this
  }

  clickOnCheckbox() {
    this.checkboxelement.parent().click()
    this.recentMAPViolationsTableHeader.should('not.contain', 'Seller')
    return this
  }

  chooseTheOption(option) {
    this.monthhistoricalviolationdetectiondata.contains(option).click()

    return this
  }


  validateDensity(density) {
    this.tableRows.first().invoke('attr', "style").then((value) => {
      cy.log('Attribute value is: ' + value);
      expect(value).to.contain(density);
    });
  }

  clickDownloadButton() {
    this.downloadButton.click()
  }

  dashboardsearch() {
    cy.reload(true);
    this.searchDashboardTable.click()
  }

  performSearch(searchTerm) {
    this.searchDashboardTable.first().click()
    this.searchInput.should('be.visible').type(searchTerm)
    this.searchButton.should('be.visible').click()
    this.tableValue.contains(searchTerm).should('be.visible')
    return this
  }


  openFilterPanel() {
    // this.searchInput.clear()
    this.filterIcon.click()
    // cy.get('.MuiPaper-root').should('be.visible') 
    return this
  }

  enterFilterDetails({ sku, url, minViolation, maxViolation, fromDate, toDate }) {

    if (sku) this.skuInput.clear().type(sku)
    if (url) this.urlInput.clear().type(url)
    if (minViolation) this.minViolationInput.clear().type(minViolation)
    if (maxViolation) this.maxViolationInput.clear().type(maxViolation)
    if (fromDate) this.fromDateInput.clear().type(fromDate)
    if (toDate) this.toDateInput.clear().type(toDate)
    this.applyFilters()
    return this
  }


  reloadPage() {
    cy.reload(true);
    return this
  }


  applyFilters() {
    this.applyFilterButton.click()

    return this
  }

  selectRowPerPage(value) {
    this.rowperPageDropdown.click()
    cy.get(`li[data-value="${value}"]`).click()
    cy.get('div.MuiTablePagination-select').should('contain', value)
    cy.get('[role="row"]').then(($rows) => {
      const rowCount = $rows.length
      // expect(rowCount).to.be.lessThan(Number(value))
      cy.log(`Found ${rowCount} rows, which is between  ${value}`)
    })
    return this
  }


  clickOnPagiNationValidateMoveOnNextPage() {
    let beforeText
    this.paginationCountElement.then(($el) => {
      beforeText = $el.text()
    })
    this.nextPageButton.click()

    this.paginationCountElement.then(($el) => {
      const afterText = $el.text()
      expect(afterText).to.not.equal(beforeText)
    })
  
    

  }





}

export default DashboardPage