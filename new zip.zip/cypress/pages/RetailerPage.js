class RetailerPage {

  get retailerTab() {
    return cy.get('[role="button"]').contains('Retailers')
  }
  get exportButton() {
    return cy.get('[aria-label="Export all retailers"]')
  }
  get filterButton() {
    return cy.get('[aria-label="Filters"]>button')
  }
  get selectClient() {
    return cy.get('[placeholder="Select Client"]')
  }
  get retailerAndsellerData() {
    return cy.get('[role="gridcell"]')
  }
  get sortInProductColumnButton() {
    return cy.get('button[aria-label="Sort"][field="product_count"]')
  }
  get searchDashboardTable() {
    return cy.get('[aria-label="Search"]')
  }

  get searchInput() {
    return cy.get('[placeholder*="Search by retailer name"]')
  }

  get tableValue() {
    return cy.get('[role="gridcell"]')
  }

  get searchButton() {
    return cy.get('button').contains('Search')
  }
  get applyFilterButton() {
    return cy.contains('button', 'Apply Filters')
  }

  get rowperPageDropdown() {
    return cy.get('div.MuiTablePagination-select')
  }

  get paginationCountElement() {
    return cy.get('[class*="MuiTablePagination-displayedRows"]')
  }

  get nextPageButton() {
    return cy.get('[aria-label="Go to next page"]')
  }

  get sellerLinkButton() {
    return cy.get("[class*='retailer-name']", { timeout: 20000 })
  }


  get retailerSellerButton() {
    return cy.get("[role='gridcell']").first()

  }

  get firstTableRow() {
    return cy.get('[role="row"]').eq(4)
  }

  get tabButton() {
    return cy.get('[aria-selected="true"]')
  }

  get tabButtons() {
    return cy.get('[type="button"]')
  }

  get subTitles() {
    return cy.get('h6')
  }

  get tableHeaders() {
    return cy.get('table thead tr th')
  }

  get itemPerPageDropdown() {
    return cy.get('[role="combobox"]')
  }

  get dropDown() {
    return cy.get('[role="combobox"]')
  }

  get nextPageButtonForComplianceHistory() {
    return cy.get('button').contains('→')
  }








  navigateToRetailerTab() {
    this.retailerTab.click()
    return this
  }

  // Methods
  verifyRetailerVisible() {
    cy.get("span").contains("Retailer").should("be.visible");
    return this
  }

  verifyRetailerContent(pageContent) {
    cy.get('body').should('not.contain', 'Loading...')

    pageContent.forEach((content) => {
      cy.get('h3').should('contain.text', content)
    }
    )
    return this

  }


  validateAllRetailerAndSellerData() {
    this.retailerAndsellerData.each(($cell) => {
      cy.wrap($cell)
        .invoke('text')
        .then((text) => {
          const hasChildElement =
            $cell.find('[aria-label="Send Communication"]').length > 0 ||
            $cell.find('[aria-label="Generate Report"]').length > 0 ||
            $cell.find('[aria-label="Report Error"]').length > 0

          if (!hasChildElement) {
            const trimmed = text.trim()
            expect(trimmed).not.to.equal('')
          }
        })
    })

  }


  verifySearchWorks(searchData) {
    cy.wait(2000)
    this.searchDashboardTable.click()
    cy.wait(1000)
    this.searchInput.should('be.visible').type(searchData)
    this.searchButton.should('be.visible').click()
    cy.wait(1000)
    this.tableValue.contains(searchData).should('be.visible')
    return this
  }


  verifyDownloadedFileCanBeOpened() {
    let expectedFileName = 'client-retailers'
    this.exportButton.click();
    cy.wait(7000);
    cy.task('readDir', 'cypress/downloads').then((files) => {
      expect(files.length, 'At least one file should be downloaded').to.be.greaterThan(0);
      const matchedFile = files.find((file) => file.includes(expectedFileName));
      expect(matchedFile, `A file containing "${expectedFileName}" should exist`).to.exist;
      cy.log(`✅ Downloaded file verified: ${matchedFile}`);
      cy.task('deleteFiles', 'cypress/downloads').then(() => {
        cy.log('🧹 All downloaded files deleted after verification');
      });
    });

    return this;
  }




  enteredFilterDetails({ MinProducts, MaxProducts, MinViolations, MaxViolations }) {
    this.filterButton.click();
    cy.log('🧩 Opening filter section...');
    const typeValueByLabel = (label, value) => {
      if (!value || value.toString().trim() === '') {
        cy.log(`⏩ Skipping ${label} — no value provided`);
        return;
      }
      cy.log(`✍️ Typing "${value}" into "${label}" field...`);
      cy.contains('span', label, { timeout: 10000 })
        .parents('.MuiFormControl-root')
        .find('input')
        .should('exist')
        .should('be.visible')
        .should(($input) => {

          expect($input.prop('disabled')).to.be.false;
        })
        .clear({ force: true }) // safe clear
        .type(value.toString(), { delay: 50 }); // add small delay for MUI re-render stability
    };


    typeValueByLabel('Min Products', MinProducts);
    typeValueByLabel('Max Products', MaxProducts);
    typeValueByLabel('Min Violations', MinViolations);
    typeValueByLabel('Max Violations', MaxViolations);

    // ✅ Apply filter
    cy.log('✅ All filter values entered, applying filter...');
    this.applyFilterButton
      .should('be.visible')
      .and('not.be.disabled')
      .click({ force: true });

    return this;
  }



  selectRowPerPage(value) {
    this.rowperPageDropdown.click()
    cy.get(`li[data-value="${value}"]`).click()
    cy.get('div.MuiTablePagination-select').should('contain', value)
    cy.get('[role="row"]').then(($rows) => {
      const rowCount = $rows.length
      // expect(rowCount).to.be.lessThan(Number(value))
      cy.log(`Found ${rowCount} rows, which is between  ${value}`)
    })
    return this
  }


  clickOnPagiNationValidateMoveOnNextPage() {
    let beforeText
    this.paginationCountElement.then(($el) => {
      beforeText = $el.text()
    })
    this.nextPageButton.click()
    this.paginationCountElement.then(($el) => {
      const afterText = $el.text()
      expect(afterText).to.not.equal(beforeText)
    })
  }




  clickOnTheSellerLinkAndValidateNavigateToAnotherTab() {
    cy.log('🔗 Clicking seller name and simulating new tab navigation...');

    cy.wait(4000);

    this.sellerLinkButton.first()
      .should('exist')                       // ✅ Ensure it’s in DOM
      .scrollIntoView()                      // ✅ Bring into viewport
      .wait(1000)                            // ✅ Give small time for rendering
      .then(($el) => {
        const domain = $el.text().trim();
        cy.log(`🌐 Seller domain found: ${domain}`);

        // If the element is hidden (0x0), skip visibility assertion and proceed
        if ($el.is(':visible')) {
          cy.wrap($el).should('be.visible');
        } else {
          cy.log('⚠️ Element not visible, using text directly.');
        }

        const fullUrl = domain.startsWith('http') ? domain : `https://${domain}`;
        cy.log(`🌍 Visiting: ${fullUrl}`);

        // Visit the URL safely (simulate opening new tab)
        cy.visit(fullUrl, { failOnStatusCode: false });

        // Validate new tab navigation
        cy.url().should('include', domain.replace('https://', ''));
        cy.title().should('not.be.empty');
        cy.log(`✅ Successfully navigated to ${domain}`);
      });

    return this;
  }

  clicktableCellData() {
    cy.log('🖱️ Clicking table cell (row area) to open internal retailer page...');

    cy.wait(2000);

    cy.contains('div[data-field="name"]', 'Chewy.com')
      .parents('[role="row"]')
      .first()
      .click('bottom', { force: true });

    // Step 2: Validate internal navigation
    cy.url().should('include', '/retailers/29201?type=retailer');
    cy.contains('Chewy.com').should('be.visible');

    cy.log('✅ Successfully navigated to BigBigMart internal retailer details page.');
  }

  checkRetailerDetails() {
    cy.get('div.MuiBox-root.css-1lekzkb')
      .contains('www.chewy.com')
      .should('be.visible')
  }
  checkCompilanceSummary() {
    cy.contains('Compliance Summary').should('be.visible');
    ['Compliance Score', 'Open Violations', 'Last Violation'].forEach(label => {
      cy.contains(label).should('be.visible');
    });

    cy.log('All Compliance Summary labels verified successfully.');

  }


  // retailer Details page methods

  verifyTabIsEnabled(tabName) {
    this.tabButton.contains(tabName).should('be.visible')
    return this
  }


  verifyTabsIsPresent(tabNames) {
    tabNames.forEach((name) => {
      this.tabButtons.contains(name).should('be.visible')
    })

    return this

  }

  verifyAllSubTitlesArePresent(subTitleNames) {
    subTitleNames.forEach((name) => {
      this.subTitles.contains(name).should('be.visible')
    })
  }

  navigateToTab(tabName) {

    this.tabButtons.contains(tabName).click()
    return this

  }

  verifyTableHeaders(expectedHeaders) {
    this.tableHeaders.each(($header, index) => {
      const expectedHeader = expectedHeaders[index]
      cy.wrap($header).should('contain.text', expectedHeader)
    })


  }

  selectItemPerPage(value) {
    this.itemPerPageDropdown.click()
    cy.get('[role="option"]').contains(value).click()
    cy.wait(2000)
    cy.get('[role="combobox"]').contains(value).should('be.visible')
    return this
  }

  selectItemPerPageForProducts(value) {
    this.itemPerPageDropdown.eq(3).click()
    cy.get('[role="option"]').contains(value).click()
    cy.wait(2000)
    cy.get('[role="combobox"]').contains(value).should('be.visible')
    return this
  }


  clickOnPagiNationValidateMoveOnNextPageInComplianceHistory() {
    let beforeText
    cy.get('p').contains("Page").then(($el) => {
      beforeText = $el.text()
    })
    this.nextPageButtonForComplianceHistory.click()
    cy.get('p').contains("Page").then(($el) => {
      const afterText = $el.text()
      expect(afterText).to.not.equal(beforeText)
    })

  }


  selectActiveStatus(option) {
    this.dropDown.contains("Active Only").eq(0).click()
    cy.get('[role="option"]').contains(option).click()
    cy.wait(2000)
  }

  selectViolationStatus(option) {
    this.dropDown.contains("All Matches").eq(0).click()
    cy.get('[role="option"]').contains(option).click()
    cy.wait(2000)
  }

  selectStockStatus(option) {
    this.dropDown.contains("All Products").click()
    cy.get('[role="option"]').contains(option).click()
    cy.wait(2000)
  }






}

export default RetailerPage