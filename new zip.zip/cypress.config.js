const { defineConfig } = require('cypress')
const fs = require('fs');
const path = require('path');

module.exports = defineConfig({
  e2e: {
    baseUrl: 'https://prowl2.wayvia.com',
    viewportWidth: 1280,
    viewportHeight: 720,
    pageLoadTimeout: 120000,
    defaultCommandTimeout: 40000,
    requestTimeout: 10000,
    responseTimeout: 10000,
    video: false,
    screenshotOnRunFailure: true,
    setupNodeEvents(on, config) {
      on('task', {
        readDir(folderPath) {
          return fs.readdirSync(folderPath);
        },

        deleteFiles(folderPath) {
          const files = fs.readdirSync(folderPath);
          files.forEach((file) => fs.unlinkSync(path.join(folderPath, file)));
          return null;
        },
      });
    },
  },
  reporter: 'mochawesome',
  reporterOptions: {
    reportDir: 'cypress/reports',
    overwrite: false,
    html: true,
    json: true,
    timestamp: 'mmddyyyy_HHMMss'
  }
})